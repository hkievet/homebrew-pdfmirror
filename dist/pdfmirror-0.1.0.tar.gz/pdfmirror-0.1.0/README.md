```
brew tap hkievet/pdfmirror
brew install pdfmirror
```

Build:

```
python3 setup.py sdist bdist_wheel
```
